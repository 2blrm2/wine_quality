def test_genric():
    a=2
    b=2
    assert a==b
